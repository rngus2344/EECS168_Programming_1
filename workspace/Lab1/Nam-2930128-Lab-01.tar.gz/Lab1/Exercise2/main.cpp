#include <iostream>

int main()
{
  std::cout << "My name is Guhyoun Nam.\nI am an EECS major.\nMy hobbies are:\n\tPlaying video games\n\tListenning to music\n\tWatching movies\nGoodbye\n";
  return(0);
}

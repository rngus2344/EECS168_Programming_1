#include "EmployeeDriver.h"

int main()
{
        EmployeeDriver myDriver;
        myDriver.run();
        return(0);
}
